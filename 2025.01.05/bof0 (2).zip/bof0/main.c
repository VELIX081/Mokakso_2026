#include <stdio.h>

void win() {
        puts("you win!!");
        puts("flag{st5ck_b6ff2r_0v2rf1ow_1s_sh1t}");
        return;
}

int main(void) {
        char buf[20];
        char pad[8];

        puts("#### Hack me!! ####");
        printf("win() address : %p\n\n", win);

        printf("your input : ");
        scanf("%s", buf);

        return 0;
}
