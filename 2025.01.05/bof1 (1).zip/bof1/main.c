#include <stdio.h>
#include <unistd.h>

void check(int key1, int key2) {
	usleep(500000);
	if (key1 == 7) {
		puts("[1] first check complete.");
		usleep(500000);
		if (key2 == 9) {
			puts("[2] second check complete.");
			puts("flag{h0w_d1d_u_h2ck2d_m2!}");
		}
		else puts("[2] failed ..");
	}
	else puts("[1] failed ..");

	return;
}

int main(void) {
	char buf[0x20];
	int key1 = 0;
	int key2 = 0;

	puts("#### bof challenge 1 ####");
	printf("your input : ");

	gets(buf);
	check(key1, key2);

	return 0;
}
