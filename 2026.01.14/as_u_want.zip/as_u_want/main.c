#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

void win() {
	int fd;
	ssize_t n;
	char flag[64];

	fd = open("./flag", O_RDONLY);
	n = read(fd, flag, sizeof(flag));
	write(STDOUT_FILENO, flag, (size_t)n);	

	return;
}

int main(void) {
	char buf[0x200];
	int len=0;

	puts("How many do you want to send?");
	write(1, "> ", 2);

	scanf("%d", &len);
	write(1, "your payload: ", 14);
	read(0, buf, len);

	return 0;
}
