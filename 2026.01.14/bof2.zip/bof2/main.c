#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>


void win() {
	int fd, n;
	char flag[64];

	fd = open("./flag", O_RDONLY);
	n = read(fd, flag, sizeof(flag));
	puts("You win!!");
	write(STDOUT_FILENO, flag, (size_t)n);

	return;
}

int main(void) {

	char buf[0x80];
	int flag = 0;

	puts("Your Input");
	write(1, "> ", 2);

	read(0, buf, 0x100);        //read는 개행문자를 인식안함

	if (flag) {
		win();
	}

	return 0;
}
