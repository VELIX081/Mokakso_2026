#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

void win() {
	int fd;
	ssize_t n;
	char flag[64];

	fd = open("./flag", O_RDONLY);
	n = read(fd, flag, sizeof(flag));
	write(STDOUT_FILENO, flag, (size_t)n);

	return;
}

int main(void) {
	char buf[0x40];

	write(1, "First input: ", 13);
	read(0, buf, 0x200);

	printf("data: %s\n\n", buf);

	write(1, "Second input: ", 14);
	scanf("%s", buf);

	return 0;
}
