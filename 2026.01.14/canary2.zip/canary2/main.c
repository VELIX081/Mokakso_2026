#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

static void init_io(void) {
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void win() {
    int fd;
    ssize_t n;
    char flag[64];

    fd = open("./flag", O_RDONLY);
    if (fd < 0) _exit(1);

    n = read(fd, flag, sizeof(flag));
    if (n > 0) write(STDOUT_FILENO, flag, (size_t)n);
    _exit(0);
}

int main(void) {
    init_io();

    char buf[0x40];

    write(1, "First input: ", 13);
    read(0, buf, 0x50);

    write(1, "echo: ", 6);
    puts(buf);

    write(1, "\nSecond input: ", 15);
    scanf("%s", buf);

    return 0;
}
