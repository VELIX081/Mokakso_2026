#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

void menu() {
	puts("1. 자기소개");
	puts("2. 내 정보");
	puts("3. 지식백구");
	write(1, "> ", 2);

	return;
}

void book_menu() {
	puts("<지식 백구>");
	puts("1. 카나리 탄생의 배경");
	puts("2. NX가 없던 시대?");		//여기부터는 이후 추가.
	puts("3. ASLR? ASMR?");
	puts("4. 두쫀쿠 먹고싶다");
	write(1, "> ", 2);

	return;
}

void explanation() {
	puts("<카나리 탄생의 배경!>");
	puts("19세기~20세기 초 광부들이 데리고 들어가던 '카나리아(canary)'는 원래 참새목 되새과(핀치류)에 속하는 작은 새로, 밝은 노란색 깃털과 맑은 울음소리로 유명해서 당시에는 애완조·사육조로도 흔했습니다.");
	puts("중요한 건 이 새가 호흡이 빠르고 몸집이 작아, 공기 중 독성 가스(특히 일산화탄소)에 노출됐을 때 사람보다 훨씬 빨리 영향을 받는다는 점이었습니다.");
	puts("그래서 광산처럼 환기가 나쁜 곳에서 가스가 새면, 사람이 증상을 느끼기 전에 카나리아가 먼저 기절하거나 쓰러져 “지금 위험하다”는 경고 신호 역할을 했고, 광부들은 그걸 보고 대피할 수 있었습니다.\n");
	puts("이 비유가 그대로 보안 용어로 들어온 게 '스택 카나리(Stack Canary)'입니다.");
	puts("스택에 '임의의 값(카나리 값)'을 미리 심어두고, 함수가 끝날 때 그 값이 변조됐는지 확인합니다.");
	puts("버퍼 오버플로우 같은 공격으로 값이 바뀌면 '스택이 오염됐다'는 신호로 판단해 프로그램을 강제 종료하죠.");
	puts("즉, 위험을 먼저 드러내는 카나리아처럼, 공격 징후를 조기에 감지한다는 의미에서 ‘카나리’라는 이름이 붙었습니다.");
	return;
}

int book() {
	int choice = 0;

	book_menu();
	scanf("%d", &choice);

	if (choice == 1) {
		explanation();
		return 0;
	}
	else {
		puts("[!] 아직 개발중입니다.");	
		return -1;
	}
}

int main(void) {
	int choice = 0, n;
	char name[0x30];
	char buf[0x60];

	puts("[*] Canary In Shell!\n");

	while(1) {
		menu();
		scanf("%d", &choice);

		if (choice == 1) {
			puts("이름을 입력해주세요.");
			write(1, "> ", 2);
			read(0, name, 0x50);
			puts("자신을 간단하게 소개해주세요.");
			write(1, "> ", 2);
			read(0, buf, 0x80);
		}
		else if (choice == 2) {
			puts("<내 정보>");
			printf("이름 : %s", name);
			puts("내 소개");
			puts(buf);
		}
		else if (choice == 3) {
			if(book() < 0) {
				puts("죄송한 마음을 담아 선물을 준비했습니다.");
				printf("buf -> %p\n", (void *)buf);
			}
		}
		else break;
	}
	return 0;
}
