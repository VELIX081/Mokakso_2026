#include <stdio.h>
#include <string.h>
#include <unistd.h>

void win() {
	execve("/bin/sh", NULL, NULL);
}

int main(void) {
	char buf[0x40];

	puts("##### PIE Challenge 0 #####");
	printf("main() Address -> %p\n\n", main);

	write(1, "Input Payload > ", 16);
	read(0, buf, 0x50);

	return 0;
}
