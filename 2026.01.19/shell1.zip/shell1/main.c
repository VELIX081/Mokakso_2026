#include <stdio.h>
#include <unistd.h>

int main(void) {
    char buf[0x60];

    setvbuf(stdout, NULL, _IONBF, 0); // stdout unbuffered

    puts("[*] Shellcode Challenge 0");
    printf("buf address -> %p\n", (void*)buf);

    write(1, "input > ", 8);
    read(0, buf, 0x70);

    return 0;
}
