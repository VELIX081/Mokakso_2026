#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main(void) {
    char buf[0x60];
    char shellcode[0x100];
    
    setvbuf(stdout, NULL, _IONBF, 0);
    
    puts("[*] Shellcode Challenge 1");
    printf("shellcode address -> %p\n", (void*)shellcode);
    
    write(1, "input shellcode > ", 18);
    read(0, shellcode, 0x100);
    
    write(1, "input payload > ", 16);
    read(0, buf, 0x80);
    
    return 0;
}
