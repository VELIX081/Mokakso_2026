#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
	char buf1[0x20];
	char buf2[0x20];
	char buf3[0x20];
	char buf4[0x20];

	puts("[*] Shellcode Challenge 2");
	printf("buf1 address -> %p\n", (void *)buf1);

	write(1, "Input Shellcode -> ", 19);
	scanf("%s", buf3);

	

	return 0;
}
